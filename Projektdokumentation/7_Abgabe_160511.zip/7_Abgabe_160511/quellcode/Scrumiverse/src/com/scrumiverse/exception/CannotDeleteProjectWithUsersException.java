package com.scrumiverse.exception;

public class CannotDeleteProjectWithUsersException extends Exception {
	private static final long serialVersionUID = -9065176236541224558L;
}