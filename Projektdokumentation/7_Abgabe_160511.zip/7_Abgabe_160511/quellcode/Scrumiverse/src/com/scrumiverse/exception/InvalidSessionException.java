package com.scrumiverse.exception;

public class InvalidSessionException extends Exception {
	private static final long serialVersionUID = -4012345490116337694L;
}