package com.scrumiverse.exception;

public class InsufficientRightsException extends Exception {
	private static final long serialVersionUID = 2163770026506306256L;
}