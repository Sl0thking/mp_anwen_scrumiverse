package com.scrumiverse.exception;

public class CategoryPersistenceException extends Exception {
	private static final long serialVersionUID = -4692971266183732140L;
}