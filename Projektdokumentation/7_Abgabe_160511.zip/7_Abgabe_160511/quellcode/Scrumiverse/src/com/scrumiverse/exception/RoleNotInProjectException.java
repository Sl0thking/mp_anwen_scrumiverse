package com.scrumiverse.exception;

public class RoleNotInProjectException extends Exception {
	private static final long serialVersionUID = -1743078796693045614L;
}