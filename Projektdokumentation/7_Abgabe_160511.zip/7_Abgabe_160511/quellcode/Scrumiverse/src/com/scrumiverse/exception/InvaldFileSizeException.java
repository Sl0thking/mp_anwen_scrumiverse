package com.scrumiverse.exception;

public class InvaldFileSizeException extends Exception {
	private static final long serialVersionUID = 252508191686699131L;
}