package com.scrumiverse.exception;

public class NotChangeableRoleException extends Exception {
	private static final long serialVersionUID = 3089213473565441915L;
}