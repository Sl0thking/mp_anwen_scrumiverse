package com.scrumiverse.exception;

public class ShutOutException extends Exception {
	private static final long serialVersionUID = -3707668091105504124L;
}