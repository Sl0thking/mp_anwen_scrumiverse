package com.scrumiverse.exception;

public class UserPersistenceException extends Exception {
	private static final long serialVersionUID = -6142479311306388677L;
}