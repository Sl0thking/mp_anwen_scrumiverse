package com.scrumiverse.exception;

public class TaskPersistenceException extends Exception {
	private static final long serialVersionUID = 343513275631880649L;
}
