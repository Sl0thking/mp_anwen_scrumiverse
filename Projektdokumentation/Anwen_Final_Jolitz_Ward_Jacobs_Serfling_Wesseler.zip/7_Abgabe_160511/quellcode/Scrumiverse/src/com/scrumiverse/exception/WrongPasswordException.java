package com.scrumiverse.exception;

public class WrongPasswordException extends Exception {
	private static final long serialVersionUID = 5455147177717015284L;
}