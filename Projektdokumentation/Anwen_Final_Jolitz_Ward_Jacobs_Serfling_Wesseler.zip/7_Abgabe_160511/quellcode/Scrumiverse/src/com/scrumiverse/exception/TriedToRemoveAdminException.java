package com.scrumiverse.exception;

public class TriedToRemoveAdminException extends Exception {
	private static final long serialVersionUID = -7349169873357340430L;
}