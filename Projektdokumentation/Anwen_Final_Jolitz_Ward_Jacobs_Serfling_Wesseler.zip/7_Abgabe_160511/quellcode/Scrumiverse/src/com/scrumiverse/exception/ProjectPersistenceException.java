package com.scrumiverse.exception;

public class ProjectPersistenceException extends Exception {
	private static final long serialVersionUID = 7124941732920159268L;
}