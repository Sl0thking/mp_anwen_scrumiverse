package com.scrumiverse.exception;

public class SprintPersistenceException extends Exception {
	private static final long serialVersionUID = -8870244162297819767L;
}