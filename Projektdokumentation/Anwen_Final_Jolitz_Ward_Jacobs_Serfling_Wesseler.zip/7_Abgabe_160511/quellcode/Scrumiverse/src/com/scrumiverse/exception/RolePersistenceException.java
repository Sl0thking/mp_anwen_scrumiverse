package com.scrumiverse.exception;

public class RolePersistenceException extends Exception {
	private static final long serialVersionUID = 899344156404546241L;
}