package com.scrumiverse.exception;

public class UserStoryPersistenceException extends Exception {
	private static final long serialVersionUID = 7081327304071103282L;
}