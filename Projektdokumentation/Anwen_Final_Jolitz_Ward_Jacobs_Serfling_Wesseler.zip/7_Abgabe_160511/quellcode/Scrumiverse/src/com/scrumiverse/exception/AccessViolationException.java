package com.scrumiverse.exception;

public class AccessViolationException extends Exception {
	private static final long serialVersionUID = 3043407341688897731L;
}
