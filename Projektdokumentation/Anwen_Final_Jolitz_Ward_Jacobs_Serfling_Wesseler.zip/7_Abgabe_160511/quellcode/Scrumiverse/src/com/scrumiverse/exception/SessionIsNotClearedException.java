package com.scrumiverse.exception;

public class SessionIsNotClearedException extends Exception {
	private static final long serialVersionUID = -6560813208646355903L;
}
