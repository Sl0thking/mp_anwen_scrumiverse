##################################################
##		Scrumiverse README		##
##################################################

l.   Inhalte der Abgabe
- Finaler Projektplan (mit Durchf�hrungsbeschreibung) - Projektplan_Final.pdf
- Finale Pr�sentation - Projektpr�sentation_Final.pdf
- (Quelldateien unter src)
- Datenbank Schema zum importieren (Mysql) - scrumiversedb.sql
- Exportiertes Projekt (unter .\quellcode\)

ll.  Repository Adresse
- https://github.com/Sl0thking/mp_anwen_scrumiverse

lll. Hinweise zum Projekt und zur MySQL DB
- Die Persistierung wurde mit Mysql realisiert. Deshalb ist eine lokale MySql DB installatiion notwendig.
  Empfohlen wird von uns XAMPP.
- Als Benutzer wird Scrumi mit dem Password root ben�tigt (mit entsprechenden Rechten)
- Eine Datenbank mit dem Namen Scrumiverse (alternativ scrumiversedb.sql importieren)



